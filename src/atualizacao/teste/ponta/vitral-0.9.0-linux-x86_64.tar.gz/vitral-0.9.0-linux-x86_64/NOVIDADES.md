## 0.9.0

Versão de teste do atualizador.
